import React, { useState, useEffect, useRef } from "react";
import {
  Heart,
  Calendar,
  MapPin,
  Music,
  Plus,
  Trash2,
  Lock,
  Unlock,
  Settings,
  X,
  FileText,
  User,
  Music2,
  ChevronRight,
  Copy,
  Check,
  Sparkles,
  Loader2,
  Camera,
  Compass,
  Volume2,
  VolumeX,
  PlusCircle,
  Eye,
  HeartHandshake
} from "lucide-react";

interface CoupleProfile {
  anniversaryDate: string;
  user1Name: string;
  user1Avatar: string;
  user2Name: string;
  user2Avatar: string;
  musicTrackUrl: string;
  musicTrackName: string;
}

interface Memory {
  id: string;
  title: string;
  description: string;
  photo: string;
  date: string;
  location: string;
}

interface Letter {
  id: string;
  title: string;
  content: string;
  author: string;
  date: string;
  theme: string;
}

// Preset sweet tracks
const PRESET_TRACKS = [
  { name: "Mây Hồng - Lofi Chill Sweet", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" },
  { name: "Hoàng Hôn Ấm Áp - Piano Nhẹ Nhàng", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3" },
  { name: "Nhịp Đập Con Tim - Acoustic Guitar", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3" },
  { name: "Thành Phố Hoàng Hôn - Lofi Beats", url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3" }
];

export default function App() {
  // Auth state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);
  const [passwordInput, setPasswordInput] = useState<string>("");
  const [authError, setAuthError] = useState<string>("");
  const [isVerifying, setIsVerifying] = useState<boolean>(false);

  // App core states
  const [profile, setProfile] = useState<CoupleProfile>({
    anniversaryDate: "2025-02-14",
    user1Name: "Anh Quân",
    user1Avatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=256&auto=format&fit=crop",
    user2Name: "Khánh Vy",
    user2Avatar: "https://images.unsplash.com/photo-1517841905240-472988babdf9?q=80&w=256&auto=format&fit=crop",
    musicTrackUrl: PRESET_TRACKS[0].url,
    musicTrackName: PRESET_TRACKS[0].name
  });
  const [memories, setMemories] = useState<Memory[]>([]);
  const [letters, setLetters] = useState<Letter[]>([]);
  const [loading, setLoading] = useState<boolean>(true);

  // Tab management
  const [activeTab, setActiveTab] = useState<"timeline" | "letters">("timeline");

  // Custom audio elements
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // Creation/Edit states
  const [isMemoryModalOpen, setIsMemoryModalOpen] = useState<boolean>(false);
  const [newMemTitle, setNewMemTitle] = useState<string>("");
  const [newMemDesc, setNewMemDesc] = useState<string>("");
  const [newMemPhoto, setNewMemPhoto] = useState<string>("");
  const [newMemDate, setNewMemDate] = useState<string>(new Date().toISOString().split("T")[0]);
  const [newMemLocation, setNewMemLocation] = useState<string>("");
  const [isSavingMemory, setIsSavingMemory] = useState<boolean>(false);

  // Letters states
  const [isLetterModalOpen, setIsLetterModalOpen] = useState<boolean>(false);
  const [newLetTitle, setNewLetTitle] = useState<string>("");
  const [newLetContent, setNewLetContent] = useState<string>("");
  const [newLetAuthor, setNewLetAuthor] = useState<string>("");
  const [newLetTheme, setNewLetTheme] = useState<string>("romantic-pink");
  const [isSavingLetter, setIsSavingLetter] = useState<boolean>(false);
  const [selectedLetter, setSelectedLetter] = useState<Letter | null>(null);

  // Settings state
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [editAnniversary, setEditAnniversary] = useState<string>("");
  const [editUser1, setEditUser1] = useState<string>("");
  const [editUser2, setEditUser2] = useState<string>("");
  const [editUser1Avatar, setEditUser1Avatar] = useState<string>("");
  const [editUser2Avatar, setEditUser2Avatar] = useState<string>("");
  const [editPassword, setEditPassword] = useState<string>("");
  const [editMusicUrl, setEditMusicUrl] = useState<string>("");
  const [editMusicName, setEditMusicName] = useState<string>("");
  const [isSavingSettings, setIsSavingSettings] = useState<boolean>(false);

  // AI assistant writing helper
  const [aiPrompt, setAiPrompt] = useState<string>("");
  const [isAiGenerating, setIsAiGenerating] = useState<boolean>(false);
  const [aiError, setAiError] = useState<string>("");

  // Initialize data
  useEffect(() => {
    fetchProfileAndData();
  }, []);

  // Sync background audio when track URL changes or isAuthenticated is true
  useEffect(() => {
    if (isAuthenticated) {
      if (!audioRef.current) {
        audioRef.current = new Audio(profile.musicTrackUrl);
        audioRef.current.loop = true;
      } else {
        audioRef.current.src = profile.musicTrackUrl;
      }
      
      if (isPlaying) {
        audioRef.current.play().catch(e => {
          console.log("Auto-play prevented by browser, waiting for interaction:", e);
          setIsPlaying(false);
        });
      }
    }
    return () => {
      if (audioRef.current) {
        audioRef.current.pause();
      }
    };
  }, [profile.musicTrackUrl, isAuthenticated]);

  const toggleMusic = () => {
    if (!audioRef.current) {
      audioRef.current = new Audio(profile.musicTrackUrl);
      audioRef.current.loop = true;
    }
    
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => {
        setIsPlaying(true);
      }).catch(err => {
        console.error("Lỗi phát nhạc:", err);
      });
    }
  };

  const fetchProfileAndData = async () => {
    try {
      const res = await fetch("/api/love-profile");
      if (res.ok) {
        const data = await res.json();
        setProfile(data.profile);
        setMemories(data.memories);
        setLetters(data.letters);
        
        // Pre-fill edit forms
        setEditAnniversary(data.profile.anniversaryDate);
        setEditUser1(data.profile.user1Name);
        setEditUser2(data.profile.user2Name);
        setEditUser1Avatar(data.profile.user1Avatar);
        setEditUser2Avatar(data.profile.user2Avatar);
        setEditMusicUrl(data.profile.musicTrackUrl);
        setEditMusicName(data.profile.musicTrackName);
      }
    } catch (err) {
      console.error("Error fetching data:", err);
    } finally {
      setLoading(false);
    }
  };

  // Password submission
  const handleVerifyPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsVerifying(true);
    setAuthError("");

    try {
      const res = await fetch("/api/verify-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ password: passwordInput })
      });

      if (res.ok) {
        setIsAuthenticated(true);
        // Play ambient music as soon as possible after user interaction
        setTimeout(() => {
          if (!audioRef.current) {
            audioRef.current = new Audio(profile.musicTrackUrl);
            audioRef.current.loop = true;
          }
          audioRef.current.play().then(() => {
            setIsPlaying(true);
          }).catch(err => {
            console.log("Audio play deferred to next click", err);
          });
        }, 500);
      } else {
        const data = await res.json();
        setAuthError(data.error || "Mật khẩu không đúng.");
      }
    } catch (err) {
      setAuthError("Lỗi kết nối đến máy chủ.");
    } finally {
      setIsVerifying(false);
    }
  };

  // Profile update save
  const handleSaveSettings = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingSettings(true);

    const payload = {
      anniversaryDate: editAnniversary,
      user1Name: editUser1,
      user1Avatar: editUser1Avatar,
      user2Name: editUser2,
      user2Avatar: editUser2Avatar,
      password: editPassword,
      musicTrackUrl: editMusicUrl,
      musicTrackName: editMusicName
    };

    try {
      const res = await fetch("/api/update-profile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });

      if (res.ok) {
        const data = await res.json();
        setProfile(data.profile);
        setIsSettingsOpen(false);
        setEditPassword(""); // clear input
      } else {
        alert("Không thể cập nhật cấu hình.");
      }
    } catch (err) {
      alert("Lỗi kết nối.");
    } finally {
      setIsSavingSettings(false);
    }
  };

  // Save new Memory
  const handleCreateMemory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMemTitle || !newMemDate) {
      alert("Tiêu đề và ngày kỉ niệm là bắt buộc.");
      return;
    }

    setIsSavingMemory(true);
    try {
      const res = await fetch("/api/memories", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: newMemTitle,
          description: newMemDesc,
          photo: newMemPhoto,
          date: newMemDate,
          location: newMemLocation
        })
      });

      if (res.ok) {
        const data = await res.json();
        setMemories(data.memories);
        setIsMemoryModalOpen(false);
        // Clear inputs
        setNewMemTitle("");
        setNewMemDesc("");
        setNewMemPhoto("");
        setNewMemDate(new Date().toISOString().split("T")[0]);
        setNewMemLocation("");
      } else {
        alert("Lỗi khi thêm kỉ niệm.");
      }
    } catch (err) {
      alert("Lỗi máy chủ.");
    } finally {
      setIsSavingMemory(false);
    }
  };

  // Delete Memory
  const handleDeleteMemory = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Bạn có chắc muốn xóa kỉ niệm ngọt ngào này không?")) return;

    try {
      const res = await fetch(`/api/memories/${id}`, {
        method: "DELETE"
      });

      if (res.ok) {
        const data = await res.json();
        setMemories(data.memories);
      }
    } catch (err) {
      alert("Lỗi khi xóa.");
    }
  };

  // Save new shared letter
  const handleCreateLetter = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newLetTitle || !newLetContent || !newLetAuthor) {
      alert("Vui lòng điền đầy đủ tiêu đề, nội dung và người viết.");
      return;
    }

    setIsSavingLetter(true);
    try {
      const res = await fetch("/api/letters", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: newLetTitle,
          content: newLetContent,
          author: newLetAuthor,
          theme: newLetTheme
        })
      });

      if (res.ok) {
        const data = await res.json();
        setLetters(data.letters);
        setIsLetterModalOpen(false);
        // Clear
        setNewLetTitle("");
        setNewLetContent("");
        setNewLetAuthor("");
        setNewLetTheme("romantic-pink");
        setAiPrompt("");
      } else {
        alert("Lỗi khi lưu thư.");
      }
    } catch (err) {
      alert("Lỗi máy chủ.");
    } finally {
      setIsSavingLetter(false);
    }
  };

  // Delete shared letter
  const handleDeleteLetter = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm("Bạn có chắc chắn muốn xóa lá thư này không?")) return;

    try {
      const res = await fetch(`/api/letters/${id}`, {
        method: "DELETE"
      });

      if (res.ok) {
        const data = await res.json();
        setLetters(data.letters);
        if (selectedLetter?.id === id) {
          setSelectedLetter(null);
        }
      }
    } catch (err) {
      alert("Lỗi khi xóa.");
    }
  };

  // Base64 Converter for Uploads
  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>, target: "memory" | "avatar1" | "avatar2") => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      const base64String = reader.result as string;
      if (target === "memory") {
        setNewMemPhoto(base64String);
      } else if (target === "avatar1") {
        setEditUser1Avatar(base64String);
      } else if (target === "avatar2") {
        setEditUser2Avatar(base64String);
      }
    };
    reader.readAsDataURL(file);
  };

  // AI assistant - Generate Love Letter text with Gemini
  const handleGenerateWithAI = async () => {
    if (!aiPrompt.trim()) {
      setAiError("Hãy viết ý tưởng hoặc lời nhắn của bạn vào đây.");
      return;
    }
    setIsAiGenerating(true);
    setAiError("");

    try {
      const res = await fetch("/api/generate-love-letter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          prompt: aiPrompt,
          tone: "lãng mạn, chân thành, bay bổng, ấm áp",
          author: newLetAuthor || profile.user1Name,
          recipient: newLetAuthor === profile.user1Name ? profile.user2Name : profile.user1Name
        })
      });

      const data = await res.json();
      if (res.ok) {
        setNewLetContent(data.letterText);
      } else {
        setAiError(data.error || "Không thể khởi tạo bằng AI.");
      }
    } catch (err) {
      setAiError("Lỗi kết nối. Hãy cấu hình API Key trong Secrets.");
    } finally {
      setIsAiGenerating(false);
    }
  };

  // Calculate Days Together
  const calculateDaysTogether = () => {
    const anniversary = new Date(profile.anniversaryDate);
    const today = new Date();
    // Clear hours to avoid partial day calculations
    anniversary.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);
    
    const diffTime = Math.abs(today.getTime() - anniversary.getTime());
    const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  // Format Date beautifully
  const formatDateVN = (dateStr: string) => {
    if (!dateStr) return "";
    try {
      const d = new Date(dateStr);
      const day = d.getDate();
      const month = d.getMonth() + 1;
      const year = d.getFullYear();
      return `Ngày ${day} tháng ${month}, năm ${year}`;
    } catch (e) {
      return dateStr;
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-rose-50 flex flex-col items-center justify-center space-y-4">
        <Heart className="w-12 h-12 text-rose-500 animate-pulse" />
        <p className="font-medium text-rose-700/80 animate-pulse font-mono text-sm">Đang tải khoảng trời bình yên của hai người...</p>
      </div>
    );
  }

  // --- 1. LOCK SCREEN (FIRST PAGE) ---
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-tr from-rose-100 via-pink-100 to-rose-200 flex flex-col items-center justify-center p-4 relative overflow-hidden" id="lock_screen">
        {/* Decorative Floating Hearts & Bubbles */}
        <div className="absolute top-10 left-10 text-rose-300 opacity-40 animate-bounce delay-150"><Heart className="w-8 h-8 fill-rose-300" /></div>
        <div className="absolute bottom-20 right-20 text-pink-300 opacity-40 animate-bounce"><Heart className="w-10 h-10 fill-pink-300" /></div>
        <div className="absolute top-1/4 right-1/4 text-rose-200 opacity-50"><Heart className="w-14 h-14 fill-rose-200 animate-pulse" /></div>

        <div className="w-full max-w-md bg-white/70 backdrop-blur-xl border border-white/50 rounded-3xl p-8 shadow-2xl shadow-rose-300/30 text-center space-y-6 relative z-10 transition-all">
          
          {/* Couple Small Initials or Avatar Peek */}
          <div className="flex items-center justify-center gap-4">
            <img
              src={profile.user1Avatar}
              alt={profile.user1Name}
              className="w-14 h-14 rounded-full object-cover ring-4 ring-rose-300 shadow-md"
            />
            <div className="w-10 h-10 bg-rose-100 rounded-full flex items-center justify-center text-rose-500 animate-pulse">
              <Heart className="w-5 h-5 fill-rose-500" />
            </div>
            <img
              src={profile.user2Avatar}
              alt={profile.user2Name}
              className="w-14 h-14 rounded-full object-cover ring-4 ring-rose-300 shadow-md"
            />
          </div>

          <div className="space-y-2">
            <h1 className="text-2xl font-bold text-slate-800 tracking-tight">Khu Vườn Kỉ Niệm</h1>
            <p className="text-xs text-rose-600 font-medium">Nơi lưu giữ những khoảnh khắc ngọt ngào của hai chúng ta</p>
          </div>

          {/* Form */}
          <form onSubmit={handleVerifyPassword} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider block">Mật khẩu yêu thương</label>
              <div className="relative">
                <input
                  type="password"
                  placeholder="Gợi ý mặc định: love"
                  value={passwordInput}
                  onChange={(e) => setPasswordInput(e.target.value)}
                  className="w-full px-5 py-3.5 bg-white border border-rose-200/80 focus:border-rose-400 focus:outline-none rounded-2xl text-center text-sm font-semibold tracking-wider placeholder:text-slate-400 transition-all shadow-inner"
                  required
                />
                <Lock className="w-4 h-4 text-rose-300 absolute left-4 top-1/2 -translate-y-1/2" />
              </div>
            </div>

            {authError && (
              <p className="text-xs text-rose-500 font-semibold bg-rose-50 p-2.5 rounded-xl border border-rose-100 animate-shake">
                {authError}
              </p>
            )}

            <button
              type="submit"
              disabled={isVerifying}
              className="w-full py-3.5 bg-gradient-to-r from-rose-500 to-pink-600 hover:from-rose-600 hover:to-pink-700 text-white rounded-2xl font-semibold text-sm shadow-md shadow-rose-500/20 hover:shadow-rose-500/30 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-75"
            >
              {isVerifying ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Đang kết nối trái tim...</span>
                </>
              ) : (
                <>
                  <Unlock className="w-4 h-4" />
                  <span>Mở Cửa Trái Tim</span>
                </>
              )}
            </button>
          </form>

          {/* Sweet Footer Quote */}
          <div className="border-t border-rose-100/60 pt-4 text-[11px] text-slate-400 font-serif italic">
            "Loving you is like breathing. How can I stop?"
          </div>
        </div>
      </div>
    );
  }

  // --- 2. MAIN COUPLE MEMORY APPLICATION DASHBOARD ---
  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans antialiased" id="love_dashboard">
      
      {/* Floating Music Visualizer & Play Controls in Corner */}
      <div className="fixed bottom-6 right-6 z-40" id="ambient_music_controller">
        <button
          onClick={toggleMusic}
          className={`p-3.5 rounded-full shadow-lg border text-white transition-all cursor-pointer flex items-center gap-2 ${
            isPlaying 
              ? "bg-gradient-to-r from-rose-500 to-pink-500 border-rose-400 animate-pulse" 
              : "bg-slate-700 hover:bg-slate-800 border-slate-600"
          }`}
          title={isPlaying ? `Đang phát: ${profile.musicTrackName}` : "Phát nhạc dạo ngọt ngào"}
        >
          {isPlaying ? (
            <>
              <div className="flex items-center gap-1">
                <span className="w-1 h-3.5 bg-white rounded-full animate-bounce delay-75"></span>
                <span className="w-1 h-4.5 bg-white rounded-full animate-bounce"></span>
                <span className="w-1 h-3 bg-white rounded-full animate-bounce delay-150"></span>
              </div>
              <span className="text-xs font-semibold max-w-[120px] truncate hidden md:inline">
                {profile.musicTrackName}
              </span>
            </>
          ) : (
            <>
              <VolumeX className="w-4 h-4" />
              <span className="text-xs font-semibold hidden md:inline">Nhạc Tắt</span>
            </>
          )}
        </button>
      </div>

      {/* Main Header navigation / Top bar */}
      <header className="sticky top-0 z-30 bg-white/80 backdrop-blur-md border-b border-rose-100" id="app_header">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Heart className="w-6 h-6 text-rose-500 fill-rose-500 animate-pulse" />
            <span className="font-bold text-slate-900 tracking-tight text-base">Khu Vườn Tình Yêu</span>
          </div>

          {/* Quick tab switchers */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
            <button
              onClick={() => setActiveTab("timeline")}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === "timeline"
                  ? "bg-white text-rose-600 shadow-xs"
                  : "text-slate-600 hover:text-slate-950"
              }`}
            >
              Kỉ Niệm Ảnh
            </button>
            <button
              onClick={() => setActiveTab("letters")}
              className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                activeTab === "letters"
                  ? "bg-white text-rose-600 shadow-xs"
                  : "text-slate-600 hover:text-slate-950"
              }`}
            >
              Hòm Thư Chung
            </button>
          </div>

          {/* Settings Trigger */}
          <button
            onClick={() => setIsSettingsOpen(true)}
            className="p-2 text-slate-500 hover:text-rose-500 hover:bg-rose-50 rounded-xl transition-all border border-transparent hover:border-rose-100 cursor-pointer"
            title="Cài đặt thông tin & mật khẩu"
          >
            <Settings className="w-4.5 h-4.5" />
          </button>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-8 space-y-8">
        
        {/* --- DYNAMIC ANNIVERSARY CARD WITH DAYS COUNT --- */}
        <section className="bg-gradient-to-tr from-rose-500 via-pink-500 to-rose-600 text-white rounded-3xl p-6 sm:p-8 shadow-xl shadow-rose-500/10 relative overflow-hidden" id="days_together_counter">
          {/* Decorative floating hearts background */}
          <div className="absolute right-0 bottom-0 opacity-10 translate-x-10 translate-y-10">
            <Heart className="w-64 h-64 fill-white" />
          </div>

          <div className="flex flex-col md:flex-row items-center justify-between gap-6 relative z-10">
            {/* Couple Avatars Face-to-Face */}
            <div className="flex items-center gap-4 sm:gap-6">
              {/* User 1 */}
              <div className="text-center space-y-2">
                <div className="relative">
                  <img
                    src={profile.user1Avatar}
                    alt={profile.user1Name}
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-full object-cover border-4 border-white/60 shadow-lg"
                  />
                  <div className="absolute bottom-0 right-0 bg-rose-500 text-white p-1 rounded-full border border-white">
                    <User className="w-3.5 h-3.5" />
                  </div>
                </div>
                <p className="text-xs sm:text-sm font-bold tracking-tight">{profile.user1Name}</p>
              </div>

              {/* Glowing animated Love Bridge */}
              <div className="flex flex-col items-center">
                <span className="text-[10px] uppercase font-bold tracking-widest text-rose-100/80 mb-1">Cột mốc</span>
                <div className="w-12 sm:w-16 h-0.5 bg-white/40 relative flex items-center justify-center">
                  <Heart className="w-5 h-5 text-white fill-white absolute animate-pulse" />
                </div>
                <span className="text-[10px] text-rose-100/80 mt-1 font-mono">{profile.anniversaryDate}</span>
              </div>

              {/* User 2 */}
              <div className="text-center space-y-2">
                <div className="relative">
                  <img
                    src={profile.user2Avatar}
                    alt={profile.user2Name}
                    className="w-16 h-16 sm:w-20 sm:h-20 rounded-full object-cover border-4 border-white/60 shadow-lg"
                  />
                  <div className="absolute bottom-0 right-0 bg-pink-500 text-white p-1 rounded-full border border-white">
                    <User className="w-3.5 h-3.5" />
                  </div>
                </div>
                <p className="text-xs sm:text-sm font-bold tracking-tight">{profile.user2Name}</p>
              </div>
            </div>

            {/* Days Count text */}
            <div className="text-center md:text-right space-y-1.5 md:border-l md:border-white/20 md:pl-8">
              <span className="text-xs sm:text-sm uppercase font-bold tracking-widest text-rose-100 block">Số ngày đồng hành</span>
              <div className="flex items-baseline justify-center md:justify-end gap-1">
                <span className="text-4xl sm:text-5xl font-extrabold tracking-tight font-mono">
                  {calculateDaysTogether()}
                </span>
                <span className="text-lg font-bold">Ngày</span>
              </div>
              <p className="text-xs text-rose-100/90 italic">"Mỗi giây phút trôi qua đều là những mẩu chuyện hạnh phúc..."</p>
            </div>
          </div>
        </section>

        {/* --- CONTENT TABS --- */}

        {/* --- TAB 1: PHOTO TIMELINE --- */}
        {activeTab === "timeline" && (
          <div className="space-y-6" id="timeline_section">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                  <Camera className="w-5 h-5 text-rose-500" />
                  Dòng Thời Gian Kỉ Niệm
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">Những khoảnh khắc được lưu giữ bằng hình ảnh, thời gian và địa điểm</p>
              </div>

              <button
                onClick={() => setIsMemoryModalOpen(true)}
                className="px-4 py-2 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-xs font-semibold shadow-md shadow-rose-500/10 hover:shadow-rose-500/20 flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Đăng Kỉ Niệm Mới
              </button>
            </div>

            {/* Memories Feed Grid */}
            {memories.length === 0 ? (
              <div className="bg-white border border-slate-200 border-dashed rounded-3xl p-16 text-center space-y-4">
                <div className="w-16 h-16 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center mx-auto">
                  <Camera className="w-8 h-8" />
                </div>
                <div className="space-y-1">
                  <p className="font-semibold text-slate-800">Chưa có tấm ảnh kỉ niệm nào được lưu trữ</p>
                  <p className="text-xs text-slate-400">Hãy nhấn Đăng Kỉ Niệm Mới để bắt đầu chụp và lưu giữ khoảnh khắc đầu tiên nhé!</p>
                </div>
                <button
                  onClick={() => setIsMemoryModalOpen(true)}
                  className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  Bắt đầu ngay
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {memories.map((mem) => (
                  <div
                    key={mem.id}
                    className="bg-white rounded-3xl overflow-hidden border border-slate-200/60 shadow-sm hover:shadow-md transition-all group flex flex-col h-full"
                  >
                    {/* Memory Photo Box */}
                    <div className="relative aspect-video w-full bg-slate-100 overflow-hidden shrink-0">
                      <img
                        src={mem.photo}
                        alt={mem.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-all duration-500"
                        referrerPolicy="no-referrer"
                      />
                      {/* Delete Memory trigger */}
                      <button
                        onClick={(e) => handleDeleteMemory(mem.id, e)}
                        className="absolute top-3 right-3 p-1.5 bg-black/40 hover:bg-rose-600 text-white rounded-full backdrop-blur-md opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
                        title="Xóa kỉ niệm này"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Content text */}
                    <div className="p-5 flex flex-col justify-between flex-1 space-y-3">
                      <div className="space-y-1.5">
                        <h3 className="font-bold text-slate-900 group-hover:text-rose-500 transition-colors text-base break-words">
                          {mem.title}
                        </h3>
                        {mem.description && (
                          <p className="text-xs text-slate-600 leading-relaxed break-words">
                            {mem.description}
                          </p>
                        )}
                      </div>

                      {/* Footer: Date & Location tags */}
                      <div className="pt-3 border-t border-slate-100 space-y-1.5">
                        <div className="flex items-center gap-1.5 text-[10.5px] text-slate-500 font-medium">
                          <Calendar className="w-3.5 h-3.5 text-rose-400" />
                          <span>{formatDateVN(mem.date)}</span>
                        </div>
                        {mem.location && (
                          <div className="flex items-center gap-1.5 text-[10.5px] text-slate-500 font-medium">
                            <MapPin className="w-3.5 h-3.5 text-rose-400" />
                            <span className="truncate">{mem.location}</span>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* --- TAB 2: SHARED LETTERS --- */}
        {activeTab === "letters" && (
          <div className="space-y-6" id="letters_section">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-rose-500" />
                  Hòm Thư Chung Sweetbox
                </h2>
                <p className="text-xs text-slate-500 mt-0.5">Những lá thư tay viết cho nhau, chứa đựng ngàn vạn lời chân thành</p>
              </div>

              <button
                onClick={() => setIsLetterModalOpen(true)}
                className="px-4 py-2 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-xs font-semibold shadow-md shadow-rose-500/10 hover:shadow-rose-500/20 flex items-center gap-1.5 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                Viết Thư Chung Mới
              </button>
            </div>

            {/* Letters List */}
            {letters.length === 0 ? (
              <div className="bg-white border border-slate-200 border-dashed rounded-3xl p-16 text-center space-y-4">
                <div className="w-16 h-16 bg-rose-50 text-rose-500 rounded-full flex items-center justify-center mx-auto">
                  <FileText className="w-8 h-8" />
                </div>
                <div className="space-y-1">
                  <p className="font-semibold text-slate-800">Hòm thư hiện đang trống rỗng</p>
                  <p className="text-xs text-slate-400">Hãy là người đầu tiên trao gửi lời nhắn thương yêu đến nửa kia của bạn!</p>
                </div>
                <button
                  onClick={() => setIsLetterModalOpen(true)}
                  className="px-4 py-2 bg-rose-50 hover:bg-rose-100 text-rose-600 border border-rose-200 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  Gửi thư đầu tiên
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {letters.map((letItem) => {
                  // Class theme mappings for sweet letter cards
                  const themeClasses = 
                    letItem.theme === "romantic-pink" 
                      ? "bg-rose-50 border-rose-200 hover:border-rose-300 text-rose-950" 
                      : letItem.theme === "warm-orange" 
                      ? "bg-amber-50 border-amber-200 hover:border-amber-300 text-amber-950" 
                      : letItem.theme === "emerald-dream" 
                      ? "bg-emerald-50 border-emerald-200 hover:border-emerald-300 text-emerald-950" 
                      : "bg-purple-50 border-purple-200 hover:border-purple-300 text-purple-950";

                  const authorBg = 
                    letItem.theme === "romantic-pink" ? "bg-rose-200/80 text-rose-800" 
                    : letItem.theme === "warm-orange" ? "bg-amber-200/80 text-amber-800"
                    : letItem.theme === "emerald-dream" ? "bg-emerald-200/80 text-emerald-800"
                    : "bg-purple-200/80 text-purple-800";

                  return (
                    <div
                      key={letItem.id}
                      onClick={() => setSelectedLetter(letItem)}
                      className={`rounded-3xl border p-6 flex flex-col justify-between space-y-4 hover:shadow-md transition-all cursor-pointer relative group ${themeClasses}`}
                    >
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteLetter(letItem.id, e);
                        }}
                        className="absolute top-4 right-4 p-1.5 rounded-full hover:bg-rose-200 text-slate-500 hover:text-rose-600 opacity-0 group-hover:opacity-100 transition-all cursor-pointer"
                        title="Xóa lá thư này"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>

                      <div className="space-y-2">
                        <span className="text-[10px] uppercase font-bold tracking-widest opacity-60">Lá Thư Yêu Thương</span>
                        <h3 className="font-extrabold text-lg tracking-tight">
                          {letItem.title}
                        </h3>
                        {/* Summary of content */}
                        <p className="text-xs line-clamp-4 leading-relaxed opacity-85 break-words">
                          {letItem.content}
                        </p>
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t border-black/5">
                        <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold ${authorBg}`}>
                          Viết bởi: {letItem.author}
                        </span>
                        <span className="text-[10px] font-mono opacity-60">{letItem.date}</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </main>

      {/* --- MODALS & DIALOGS --- */}

      {/* --- 1. SETTINGS / PROFILE CUSTOMIZER MODAL --- */}
      {isSettingsOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-slate-200 w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-rose-500" />
                <div>
                  <h3 className="font-bold text-slate-950">Chỉnh Sửa Hồ Sơ & Nhạc Dạo</h3>
                  <p className="text-xs text-slate-500">Cấu hình tên, ảnh đại diện, nhạc nền và mật khẩu của hai người</p>
                </div>
              </div>
              <button
                onClick={() => setIsSettingsOpen(false)}
                className="p-1.5 hover:bg-slate-100 text-slate-400 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveSettings} className="p-6 space-y-5 overflow-y-auto flex-1">
              {/* Couple profile segment */}
              <div className="space-y-3">
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Thông tin 2 người</h4>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* User 1 Details */}
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-3">
                    <span className="text-[10px] uppercase font-bold text-indigo-600 block">Thành viên 1 (Anh)</span>
                    <div className="space-y-2">
                      <label className="block text-[11px] font-semibold text-slate-500">Tên hiển thị</label>
                      <input
                        type="text"
                        value={editUser1}
                        onChange={(e) => setEditUser1(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="block text-[11px] font-semibold text-slate-500">Ảnh đại diện (File / URL)</label>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleImageUpload(e, "avatar1")}
                        className="block w-full text-[10px] text-slate-500 file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:text-[10px] file:font-semibold file:bg-rose-50 file:text-rose-700 hover:file:bg-rose-100"
                      />
                      <input
                        type="text"
                        value={editUser1Avatar}
                        onChange={(e) => setEditUser1Avatar(e.target.value)}
                        className="w-full px-3 py-1 bg-white border border-slate-200 focus:outline-rose-400 rounded-lg text-[10px] font-mono"
                        placeholder="Hoặc điền link hình ảnh Unsplash..."
                      />
                    </div>
                  </div>

                  {/* User 2 Details */}
                  <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-3">
                    <span className="text-[10px] uppercase font-bold text-pink-600 block">Thành viên 2 (Em)</span>
                    <div className="space-y-2">
                      <label className="block text-[11px] font-semibold text-slate-500">Tên hiển thị</label>
                      <input
                        type="text"
                        value={editUser2}
                        onChange={(e) => setEditUser2(e.target.value)}
                        className="w-full px-3 py-1.5 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs"
                        required
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="block text-[11px] font-semibold text-slate-500">Ảnh đại diện (File / URL)</label>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleImageUpload(e, "avatar2")}
                        className="block w-full text-[10px] text-slate-500 file:mr-2 file:py-1 file:px-2 file:rounded-md file:border-0 file:text-[10px] file:font-semibold file:bg-rose-50 file:text-rose-700 hover:file:bg-rose-100"
                      />
                      <input
                        type="text"
                        value={editUser2Avatar}
                        onChange={(e) => setEditUser2Avatar(e.target.value)}
                        className="w-full px-3 py-1 bg-white border border-slate-200 focus:outline-rose-400 rounded-lg text-[10px] font-mono"
                        placeholder="Hoặc điền link hình ảnh Unsplash..."
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Anniversary Date config */}
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Ngày bắt đầu yêu nhau (Anniversary Date)</label>
                <input
                  type="date"
                  value={editAnniversary}
                  onChange={(e) => setEditAnniversary(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs font-semibold"
                  required
                />
              </div>

              {/* Background Music settings */}
              <div className="space-y-3">
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Nhạc dạo khi mở trang web</label>
                
                {/* Select standard track */}
                <div className="space-y-1.5">
                  <span className="block text-[11px] font-semibold text-slate-500">Chọn bản nhạc dạo yêu thích có sẵn:</span>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {PRESET_TRACKS.map((track) => (
                      <button
                        key={track.name}
                        type="button"
                        onClick={() => {
                          setEditMusicName(track.name);
                          setEditMusicUrl(track.url);
                        }}
                        className={`px-3 py-2 border rounded-xl text-xs text-left font-medium transition-all flex items-center justify-between cursor-pointer ${
                          editMusicUrl === track.url
                            ? "bg-rose-50 border-rose-300 text-rose-700 font-semibold"
                            : "bg-white border-slate-200 text-slate-700 hover:bg-slate-50"
                        }`}
                      >
                        <span className="truncate">{track.name}</span>
                        {editMusicUrl === track.url && <Check className="w-3.5 h-3.5 text-rose-500 shrink-0 ml-1" />}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Custom music input */}
                <div className="space-y-2 pt-1.5">
                  <span className="block text-[11px] font-semibold text-slate-500">Tự cài đặt bản nhạc dạo khác (định dạng .mp3):</span>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    <input
                      type="text"
                      placeholder="Tên bài nhạc..."
                      value={editMusicName}
                      onChange={(e) => setEditMusicName(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs"
                    />
                    <input
                      type="text"
                      placeholder="Đường dẫn âm thanh (.mp3)..."
                      value={editMusicUrl}
                      onChange={(e) => setEditMusicUrl(e.target.value)}
                      className="w-full px-3 py-2 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs font-mono"
                    />
                  </div>
                </div>
              </div>

              {/* Password change security */}
              <div className="space-y-2 border-t border-slate-100 pt-4">
                <label className="block text-xs font-bold text-slate-400 uppercase tracking-wider">Đổi mật khẩu bảo vệ trang đầu</label>
                <input
                  type="password"
                  placeholder="Nhập mật khẩu yêu thương mới (để trống nếu muốn giữ nguyên)..."
                  value={editPassword}
                  onChange={(e) => setEditPassword(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs font-semibold"
                />
              </div>

              {/* Controls */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsSettingsOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  Đóng
                </button>
                <button
                  type="submit"
                  disabled={isSavingSettings}
                  className="px-5 py-2 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer disabled:opacity-75"
                >
                  {isSavingSettings && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  Lưu thay đổi
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- 2. ADD MEMORY MODAL --- */}
      {isMemoryModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-slate-200 w-full max-w-lg overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <Camera className="w-5 h-5 text-rose-500" />
                <div>
                  <h3 className="font-bold text-slate-950">Thêm Tấm Ảnh Kỉ Niệm</h3>
                  <p className="text-xs text-slate-500">Lưu lại thời gian, địa điểm và câu chuyện tình yêu</p>
                </div>
              </div>
              <button
                onClick={() => setIsMemoryModalOpen(false)}
                className="p-1.5 hover:bg-slate-100 text-slate-400 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateMemory} className="p-6 space-y-4 overflow-y-auto flex-1">
              {/* Title */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Tiêu đề kỉ niệm</label>
                <input
                  type="text"
                  placeholder="Ví dụ: Chuyến dã ngoại công viên, Đêm giáng sinh..."
                  value={newMemTitle}
                  onChange={(e) => setNewMemTitle(e.target.value)}
                  className="w-full px-3 py-2.5 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs font-medium"
                  required
                />
              </div>

              {/* Photo Upload selector or Link */}
              <div className="space-y-2 bg-slate-50 p-4 rounded-2xl border border-slate-100">
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Hình ảnh kỉ niệm</label>
                
                <div className="space-y-2">
                  <div className="flex items-center gap-2">
                    <input
                      type="file"
                      accept="image/*"
                      onChange={(e) => handleImageUpload(e, "memory")}
                      className="block w-full text-[10px] text-slate-500 file:mr-2 file:py-1.5 file:px-2.5 file:rounded-xl file:border-0 file:text-[10px] file:font-semibold file:bg-rose-50 file:text-rose-700 hover:file:bg-rose-100"
                    />
                  </div>
                  
                  <span className="block text-[10px] text-slate-400 font-medium text-center">Hoặc dán trực tiếp đường dẫn ảnh:</span>
                  
                  <input
                    type="text"
                    placeholder="Dán link ảnh từ Unsplash/Pinterest..."
                    value={newMemPhoto}
                    onChange={(e) => setNewMemPhoto(e.target.value)}
                    className="w-full px-3 py-1.5 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs font-mono"
                  />
                </div>

                {newMemPhoto && (
                  <div className="mt-3 relative aspect-video rounded-xl overflow-hidden border border-slate-200 bg-white">
                    <img
                      src={newMemPhoto}
                      alt="Xem trước hình ảnh"
                      className="w-full h-full object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => setNewMemPhoto("")}
                      className="absolute top-2 right-2 p-1 bg-black/60 text-white rounded-full hover:bg-rose-600"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                )}
              </div>

              {/* Date & Location Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Thời gian kỉ niệm</label>
                  <input
                    type="date"
                    value={newMemDate}
                    onChange={(e) => setNewMemDate(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs"
                    required
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Địa điểm lưu dấu</label>
                  <input
                    type="text"
                    placeholder="Ví dụ: Phố đi bộ Hà Nội, Bãi biển..."
                    value={newMemLocation}
                    onChange={(e) => setNewMemLocation(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs"
                  />
                </div>
              </div>

              {/* Description */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Câu chuyện ngắn / Cảm xúc</label>
                <textarea
                  placeholder="Ghi lại đôi dòng cảm nghĩ của bạn về ngày hôm ấy..."
                  value={newMemDesc}
                  onChange={(e) => setNewMemDesc(e.target.value)}
                  rows={3}
                  className="w-full p-3 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs leading-relaxed"
                />
              </div>

              {/* Controls */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsMemoryModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  Đóng
                </button>
                <button
                  type="submit"
                  disabled={isSavingMemory}
                  className="px-5 py-2 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer disabled:opacity-75"
                >
                  {isSavingMemory && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  Đăng lưu giữ
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- 3. WRITE SHARED LETTER MODAL WITH GEMINI AI OPTION --- */}
      {isLetterModalOpen && (
        <div className="fixed inset-0 z-50 bg-slate-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-slate-200 w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-slate-100 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-rose-500" />
                <div>
                  <h3 className="font-bold text-slate-950">Viết Thư Chung Mới</h3>
                  <p className="text-xs text-slate-500">Viết những lời thầm kín, sưởi ấm tâm hồn cho nhau</p>
                </div>
              </div>
              <button
                onClick={() => setIsLetterModalOpen(false)}
                className="p-1.5 hover:bg-slate-100 text-slate-400 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateLetter} className="p-6 space-y-4 overflow-y-auto flex-1">
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Author Selection */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Người viết thư này</label>
                  <select
                    value={newLetAuthor}
                    onChange={(e) => setNewLetAuthor(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs font-semibold"
                    required
                  >
                    <option value="">-- Chọn danh tính của bạn --</option>
                    <option value={profile.user1Name}>{profile.user1Name} (Anh)</option>
                    <option value={profile.user2Name}>{profile.user2Name} (Em)</option>
                  </select>
                </div>

                {/* Theme selection */}
                <div className="space-y-1.5">
                  <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Phong cách màu thư</label>
                  <select
                    value={newLetTheme}
                    onChange={(e) => setNewLetTheme(e.target.value)}
                    className="w-full px-3 py-2 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs font-semibold"
                    required
                  >
                    <option value="romantic-pink">Hồng Lãng Mạn</option>
                    <option value="warm-orange">Cam Ấm Áp</option>
                    <option value="emerald-dream">Xanh Ngọc Yên Bình</option>
                    <option value="royal-violet">Tím Thuỷ Chung</option>
                  </select>
                </div>
              </div>

              {/* Letter Title */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Tiêu đề bức thư</label>
                <input
                  type="text"
                  placeholder="Ví dụ: Gửi người bạn đời tương lai, Thư xin lỗi đáng yêu..."
                  value={newLetTitle}
                  onChange={(e) => setNewLetTitle(e.target.value)}
                  className="w-full px-3 py-2.5 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs font-medium"
                  required
                />
              </div>

              {/* AI helper box */}
              <div className="bg-indigo-50/50 border border-indigo-100 rounded-2xl p-4 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-indigo-950 flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse" />
                    Trợ lý tình yêu AI (Gemini Assistant)
                  </span>
                  <span className="text-[10px] bg-indigo-100 text-indigo-700 px-1.5 py-0.5 rounded font-bold">AI Support</span>
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  Nhập tâm trạng, cảm xúc hoặc một sự việc đặc biệt nào đó, Trợ lý AI sẽ giúp bạn phác thảo một bài thơ hoặc bức thư tình lãng mạn dạt dào cảm xúc.
                </p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    placeholder="Ví dụ: Viết một lời nhắn dễ thương để làm lành sau một cuộc giận dỗi nhẹ..."
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                    className="flex-1 px-3 py-2 bg-white border border-slate-200 focus:outline-rose-400 rounded-xl text-xs"
                  />
                  <button
                    type="button"
                    onClick={handleGenerateWithAI}
                    disabled={isAiGenerating}
                    className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold shrink-0 flex items-center gap-1 cursor-pointer disabled:opacity-75"
                  >
                    {isAiGenerating ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        <span>Đang viết...</span>
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-3.5 h-3.5" />
                        <span>Tạo Thư</span>
                      </>
                    )}
                  </button>
                </div>
                {aiError && (
                  <p className="text-[10px] text-rose-600 font-semibold">{aiError}</p>
                )}
              </div>

              {/* Letter Content */}
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-500 uppercase tracking-wider">Nội dung bức thư</label>
                <textarea
                  placeholder="Gửi ngàn lời nhớ nhung vào đây..."
                  value={newLetContent}
                  onChange={(e) => setNewLetContent(e.target.value)}
                  rows={8}
                  className="w-full p-4 bg-amber-50/40 border border-slate-200 focus:outline-rose-400 rounded-2xl text-xs font-serif leading-relaxed text-slate-800"
                  required
                />
              </div>

              {/* Controls */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-2.5">
                <button
                  type="button"
                  onClick={() => setIsLetterModalOpen(false)}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold cursor-pointer"
                >
                  Đóng
                </button>
                <button
                  type="submit"
                  disabled={isSavingLetter}
                  className="px-5 py-2 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-xs font-semibold flex items-center gap-1 cursor-pointer disabled:opacity-75"
                >
                  {isSavingLetter && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  Cất thư vào Hòm
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* --- 4. VIEW SINGLE SELECTED LETTER POPUP --- */}
      {selectedLetter && (
        <div className="fixed inset-0 z-50 bg-slate-900/50 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-slate-200 w-full max-w-xl overflow-hidden shadow-2xl flex flex-col max-h-[85vh]">
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/55">
              <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 flex items-center gap-1.5">
                <Eye className="w-4 h-4 text-rose-500" />
                Đang đọc thư của {selectedLetter.author}
              </span>
              <button
                onClick={() => setSelectedLetter(null)}
                className="p-1.5 hover:bg-slate-100 text-slate-400 rounded-xl"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Styled reading parchment */}
            <div className="p-8 sm:p-10 overflow-y-auto flex-1 bg-amber-50/30 font-serif leading-loose text-slate-800 space-y-6 relative">
              {/* Subtle background stamps or watermarks */}
              <div className="absolute top-8 right-8 text-rose-200/20 rotate-12 select-none pointer-events-none">
                <Heart className="w-32 h-32 fill-rose-200/25" />
              </div>

              <div className="space-y-2 relative z-10 text-center border-b border-slate-200/80 pb-4">
                <h3 className="text-xl sm:text-2xl font-extrabold tracking-tight text-slate-900 font-sans">
                  {selectedLetter.title}
                </h3>
                <div className="text-[11px] text-slate-500 font-sans flex items-center justify-center gap-1.5">
                  <span>Viết bởi: <strong className="text-rose-600">{selectedLetter.author}</strong></span>
                  <span>•</span>
                  <span>{selectedLetter.date}</span>
                </div>
              </div>

              {/* Main content body formatted beautifully */}
              <div className="text-sm sm:text-base text-slate-800 whitespace-pre-line relative z-10 break-words font-serif text-justify leading-relaxed">
                {selectedLetter.content}
              </div>

              {/* End Sign */}
              <div className="text-right pt-6 relative z-10 font-sans">
                <span className="text-xs text-slate-400 block font-medium">Thân gửi,</span>
                <span className="font-serif italic text-rose-600 font-bold text-base block mt-1">{selectedLetter.author}</span>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-end">
              <button
                onClick={() => setSelectedLetter(null)}
                className="px-5 py-2 bg-rose-500 hover:bg-rose-600 text-white rounded-xl text-xs font-semibold cursor-pointer shadow-sm shadow-rose-500/10"
              >
                Đã đọc xong
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
